import type { Node, NodeTypes } from "reactflow";
import { PositionLoggerNode } from "./PositionLoggerNode";
import {AndNode} from "./AndNode.tsx";
import {OrNode} from "./OrNode.tsx";

export const initialNodes = [
 /*{ id: "a", type: "input", position: { x: 0, y: 0 }, data: { label: "wire" } },
  {
    id: "b",
    type: "position-logger",
    position: { x: -100, y: 100 },
    data: { label: "drag me!" },
  },
  { id: "c", position: { x: 100, y: 100 }, data: { label: "your ideas" } },
  {
    id: "d",
    type: "output",
    position: { x: 0, y: 200 },
    data: { label: "with React Flow" },
  },*/
  {id:"e", type:"and-node", position:{x:100, y:100}, data: { label: "&" }},
  {id:"f", type:"or-node", position:{x:400, y:100}, data: { label: ">=1" }},
  ] satisfies Node[];

export const nodeTypes = {
  "position-logger": PositionLoggerNode,
  "and-node": AndNode,
  "or-node": OrNode,
  // Add any of your custom nodes here!
} satisfies NodeTypes;
