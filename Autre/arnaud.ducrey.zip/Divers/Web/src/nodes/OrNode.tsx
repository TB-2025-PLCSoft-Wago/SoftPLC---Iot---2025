import { Handle, Position } from 'reactflow';
import type { NodeProps } from "reactflow";
import {useMemo} from "react";

export type AndNodeData = {
    label?: string;
};

export function OrNode({data}: NodeProps<AndNodeData>) {
    const handleVisability = true;
    const handleStyle = useMemo(
        () => ({
            height: handleVisability ? 8 : 0,
            width: handleVisability ? 8 : 0
        }),
        [handleVisability]
    );

    const handleStyleSideBottom = useMemo(
        () => ({
            height: handleVisability ? 8 : 0,
            width: handleVisability ? 8 : 0,
            top: "70%"
        }),
        [handleVisability]
    );

    const handleStyleSideTop = useMemo(
        () => ({
            height: handleVisability ? 8 : 0,
            width: handleVisability ? 8 : 0,
            top: "30%"
        }),
        [handleVisability]
    );
    return (
        <div className="react-flow__node-default or-node">
            {data.label && <div>{data.label}</div>}
            <Handle style={handleStyleSideTop} type="target" position={Position.Left} id="Input1" isConnectable={true}></Handle>
            <Handle style={handleStyleSideBottom} type="target" position={Position.Left} id="Input2" isConnectable={true}></Handle>
            <Handle style={handleStyle} type="source" position={Position.Right} id="Output" isConnectable={true}></Handle>
        </div>
    )
}