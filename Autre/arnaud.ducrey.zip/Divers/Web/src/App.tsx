/*import type { OnConnect } from "reactflow";

import { useCallback } from "react";
import {
  Background,
  Controls,
  MiniMap,
  ReactFlow,
  addEdge,
  useNodesState,
  useEdgesState,
  Panel,
} from "reactflow";

import "reactflow/dist/style.css";

//import DevTools from "./DevTools.tsx";


import { initialNodes, nodeTypes } from "./nodes";
import { initialEdges, edgeTypes } from "./edges";

export default function App() {
  const [nodes, , onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
  const onConnect: OnConnect = useCallback(
      (connection) => setEdges((edges) => addEdge(connection, edges)),
      [setEdges]
  );

  function onSave() {
    console.log({ nodes, edges });
    const data = { nodes, edges };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'data.json';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }



  return (
        <ReactFlow
            nodes={nodes}
            nodeTypes={nodeTypes}
            onNodesChange={onNodesChange}
            edges={edges}
            edgeTypes={edgeTypes}
            onEdgesChange={onEdgesChange}
            onConnect={onConnect}
            fitView
        >
          <Panel position="top-right">
            <button onClick={onSave}>save</button>
          </Panel>
          <Background/>
          <MiniMap/>
          <Controls/>

        </ReactFlow>

  );
}*/
import DevTools from "./DevTools.tsx";
import React, { useState, useRef, useCallback } from 'react';
import {
  Background,
  Controls,
  MiniMap,
  ReactFlow,
  ReactFlowProvider,
  addEdge,
  useNodesState,
  useEdgesState,
  Panel,
  OnConnect,
  OnDragOver,
  OnDrop,
} from "reactflow";

import 'reactflow/dist/style.css';

import Sidebar from './Sidebar';

import { initialNodes, nodeTypes } from './nodes';
import { initialEdges, edgeTypes } from './edges';


let id = 0;
const getId = (): string => `${id++}`;

export default function App() {
  const reactFlowWrapper = useRef<HTMLDivElement | null>(null);
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
  const [reactFlowInstance, setReactFlowInstance] = useState<any>(null);

  const onConnect: OnConnect = useCallback(
      (connection) => setEdges((eds) => addEdge(connection, eds)),
      [setEdges]
  );

  const onDragOver: OnDragOver = useCallback((event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop: OnDrop = useCallback(
      (event) => {
        event.preventDefault();

        const type = event.dataTransfer.getData('application/reactflow');

        if (typeof type === 'undefined' || !type) {
          return;
        }

        const position = reactFlowInstance.screenToFlowPosition({
          x: event.clientX,
          y: event.clientY,
        });

        let label = "";
        if (type === "input") {
          label = "Input Node";
        } else if (type === "and-node") {
          label = "&";
        } else if (type === "or-node") {
          label = ">=1";
        }
        const newNode: nodeTypes = {
          id: getId(),
          type,
          position,
          data: { label: label },
        };

        setNodes((nds) => nds.concat(newNode));
      },
      [reactFlowInstance]
  );

  const onSave = () => {
    console.log({ nodes, edges });
    const data = { nodes, edges };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'data.json';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
      <ReactFlowProvider>
        <div className="dndflow">
          <div className="reactflow-wrapper" ref={reactFlowWrapper}  style={{ height: '100vh', width: '100%' }}>
            <ReactFlow
                nodes={nodes}
                nodeTypes={nodeTypes}
                onNodesChange={onNodesChange}
                edges={edges}
                edgeTypes={edgeTypes}
                onEdgesChange={onEdgesChange}
                onConnect={onConnect}
                onInit={setReactFlowInstance}
                onDrop={onDrop}
                onDragOver={onDragOver}
                fitView
            >
              <Panel position="top-right">
                <button onClick={onSave}>save</button>
              </Panel>
              <Background />
              <MiniMap />
              <Controls />
              <DevTools />
            </ReactFlow>
          </div>
          <Sidebar />
        </div>
      </ReactFlowProvider>
  );
}

