import type { Edge, EdgeTypes } from "reactflow";

export const initialEdges = [
] satisfies Edge[];

export const edgeTypes = {
  // Add your custom edge types here!
} satisfies EdgeTypes;
