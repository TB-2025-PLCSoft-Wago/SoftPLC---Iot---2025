import React from 'react';

const Sidebar: React.FC = () => {
    const onDragStart = (event: React.DragEvent<HTMLDivElement>, nodeType: string) => {
        event.dataTransfer.setData('application/reactflow', nodeType);
        event.dataTransfer.effectAllowed = 'move';
    };

    return (
        <aside>
            <div className="description">Drag the bloc you want to add.</div>
            <div className="dndnode input" onDragStart={(event) => onDragStart(event, 'input')} draggable>
                Input Node
            </div>
            <div className="dndnode" onDragStart={(event) => onDragStart(event, 'and-node')} draggable>
                And Node
            </div>
            <div className="dndnode" onDragStart={(event) => onDragStart(event, 'or-node')} draggable>
                Or Node
            </div>
        </aside>
    );
};

export default Sidebar;
